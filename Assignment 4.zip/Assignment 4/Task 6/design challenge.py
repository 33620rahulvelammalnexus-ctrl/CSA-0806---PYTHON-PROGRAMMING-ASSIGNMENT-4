
import os

# College Fest Registration Desk

INPUT_DIR = "input"
OUTPUT_DIR = "output"

files = [
    "dept1.txt",
    "dept2.txt",
    "dept3.txt",
    "dept4.txt",
    "dept5.txt"
]

# Create input folder
os.makedirs(INPUT_DIR, exist_ok=True)

# Sample department files
sample_data = {
    "dept1.txt": [
        "101|Arun|CSE|arun@gmail.com|Dance;Singing",
        "102|Bala|IT|bala@gmail.com|Drama",
        "103|Kumar|ECE|invalidmail|Singing"
    ],
    "dept2.txt": [
        "101|Arun|CSE|arun@gmail.com|Dance;Singing",
        "104|Ravi|EEE|ravi@gmail.com|Photography",
        "Damaged line"
    ],
    "dept3.txt": [
        "105|Priya|CSE|priya@gmail.com|Dance"
    ]
}

for filename, records in sample_data.items():
    with open(os.path.join(INPUT_DIR, filename), "w") as f:
        f.write("\n".join(records) + "\n")


# Validate email
def validate_email(email):
    email = email.strip().lower()

    if email.count("@") != 1:
        return False

    if " " in email:
        return False

    local, domain = email.split("@")

    if not local or "." not in domain:
        return False

    if domain.startswith(".") or domain.endswith("."):
        return False

    return True


# Validate student record
def validate_record(line):
    fields = line.strip().split("|")

    if len(fields) != 5:
        return None

    reg, name, dept, email, events = fields

    if not all(x.strip() for x in fields):
        return None

    if not validate_email(email):
        return None

    return {
        "reg": reg.strip(),
        "name": name.strip(),
        "dept": dept.strip(),
        "email": email.strip().lower(),
        "events": [
            e.strip() for e in events.split(";") if e.strip()
        ]
    }


# Main processing
def main():

    master = []
    seen = set()
    errors = []

    print("\nCOLLEGE FEST REGISTRATION SYSTEM")
    print("--------------------------------")

    for filename in files:

        path = os.path.join(INPUT_DIR, filename)

        try:
            with open(path, "r") as f:
                lines = f.readlines()

            for line_no, line in enumerate(lines, 1):

                try:
                    student = validate_record(line)

                    if student is None:
                        errors.append(
                            f"{filename}, Line {line_no}: "
                            "Invalid email or damaged record"
                        )
                        continue

                    reg = student["reg"]

                    if reg in seen:
                        errors.append(
                            f"{filename}, Line {line_no}: "
                            f"Duplicate registration {reg}"
                        )
                        continue

                    seen.add(reg)
                    master.append(student)

                except Exception as e:
                    errors.append(
                        f"{filename}, Line {line_no}: {e}"
                    )

        except FileNotFoundError:
            errors.append(filename + " - File missing")

        except OSError as e:
            errors.append(filename + " - " + str(e))

    # Create output folders
    os.makedirs(os.path.join(OUTPUT_DIR, "events"),
                exist_ok=True)

    # Write master list
    with open(os.path.join(OUTPUT_DIR, "master.txt"),
              "w") as f:

        for s in master:
            f.write(
                f'{s["reg"]}|{s["name"]}|{s["dept"]}|'
                f'{s["email"]}|{";".join(s["events"])}\n'
            )

    # Create event-wise participant lists
    event_lists = {}

    for s in master:
        for event in s["events"]:
            event_lists.setdefault(event, []).append(s)

    for event, students in event_lists.items():

        filename = event.replace("/", "_") + ".txt"
        path = os.path.join(OUTPUT_DIR, "events", filename)

        with open(path, "w") as f:
            for s in students:
                f.write(
                    s["reg"] + " - " + s["name"] + "\n"
                )

    # Generate summary report
    with open(os.path.join(OUTPUT_DIR, "summary.txt"),
              "w") as f:

        f.write("COLLEGE FEST SUMMARY REPORT\n")
        f.write("---------------------------\n")
        f.write(f"Total registrations: {len(master)}\n\n")

        for event, students in event_lists.items():
            f.write(
                f"{event}: {len(students)} participants\n"
            )

    # Generate error log
    with open(os.path.join(OUTPUT_DIR, "errors.txt"),
              "w") as f:

        for error in errors:
            f.write(error + "\n")

    # Display results
    print("\nPROCESSING COMPLETED!")
    print("---------------------")
    print("Valid registrations:", len(master))
    print("Total errors:", len(errors))

    print("\nMASTER REGISTRATION LIST")

    for s in master:
        print(s["reg"], "-", s["name"], "-", s["dept"])

    print("\nEVENT-WISE PARTICIPANTS")

    for event, students in event_lists.items():
        print(event, ":", len(students))

    print("\nERROR LOG")

    for error in errors:
        print(error)

    print("\nOutput files saved in the 'output' folder.")


# Run program
if __name__ == "__main__":
    main()
