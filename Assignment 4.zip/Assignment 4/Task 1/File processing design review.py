import decimal


def parse_line(line):
    """Check one line. Returns (name, amount, error_message).
    If the line is good, error_message is None."""
    parts = line.split(",")
    if len(parts) != 3:
        return None, None, "Expected 3 fields"

    name = parts[1].strip()
    amount_text = parts[2].strip()

    try:
        amount = decimal.Decimal(amount_text)          # accepts 1250.50
    except decimal.InvalidOperation:
        return None, None, "Amount is not a number"

    if not amount.is_finite() or amount < 0:
        return None, None, "Invalid amount"

    return name, amount, None


def process_mess_file(file_name):
    """TASK 1.2 - main solution: reads ONE line at a time.
    Returns: total, report_lines, rejected"""
    total = decimal.Decimal("0")
    report_lines = []
    rejected = []                              # (line number, line, reason)

    with open(file_name, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, start=1):
            line = line.strip()
            if line == "":                     # skip empty lines
                continue

            name, amount, error = parse_line(line)
            if error is not None:
                rejected.append((line_no, line, error))
                continue

            total = total + amount
            report_lines.append(name + " " + format(amount, ".2f"))

    return total, report_lines, rejected


def process_mess_file_readlines(file_name):
    """ALTERNATIVE CONCEPT: loads the WHOLE file with readlines()."""
    total = decimal.Decimal("0")
    report_lines = []
    rejected = []

    with open(file_name, "r", encoding="utf-8") as f:
        all_lines = f.readlines()              # whole file in memory

    for line_no, line in enumerate(all_lines, start=1):
        line = line.strip()
        if line == "":
            continue

        name, amount, error = parse_line(line)
        if error is not None:
            rejected.append((line_no, line, error))
            continue

        total = total + amount
        report_lines.append(name + " " + format(amount, ".2f"))

    return total, report_lines, rejected


def show_result(total, report_lines, rejected):
    print("MESS BILL REPORT")
    print("\n".join(report_lines))
    print("Total:", format(total, ".2f"))
    print("\nRejected lines:", len(rejected))
    for line_no, text, reason in rejected:
        print("Line", line_no, "->", text, "(" + reason + ")")


def main():
    file_name = "mess_oct.txt"

    # Create a small sample file so the program runs directly
    with open(file_name, "w", encoding="utf-8") as f:
        f.write("101,Arun,1250.50\n")
        f.write("102,Meena,1300\n")
        f.write("103,Karthik,abc\n")
        f.write("104,Divya\n")
        f.write("105,Ravi,-50\n")
        f.write("106,Priya,1100.25\n")
        f.write("\n")

    # ---- Main solution (line by line) ----
    try:
        total, report_lines, rejected = process_mess_file(file_name)
    except FileNotFoundError:
        print("Error: file", file_name, "was not found.")
        return
    except PermissionError:
        print("Error: no permission to read", file_name)
        return
    except UnicodeDecodeError:
        print("Error: file is not valid UTF-8 text.")
        return

    show_result(total, report_lines, rejected)

    # ---- Alternative (readlines) must give the same answer ----
    total2, report2, rejected2 = process_mess_file_readlines(file_name)
    print("\nSame result with readlines()?",
          total == total2 and report_lines == report2 and rejected == rejected2)

    # ---- Test a missing file ----
    print("\nTesting a missing file:")
    try:
        process_mess_file("no_such_file.txt")
    except FileNotFoundError:
        print("Error: file no_such_file.txt was not found.")


main()