# TASK 4 - FILE AND EXCEPTION FORENSICS (library returns log)
# Run:  python task4_file_forensics.py

import builtins
import os
import shutil
import tempfile
from datetime import datetime


def heading(text):
    print("\n" + "=" * 62)
    print(text)
    print("=" * 62)


# ------------------------------------------------------------
# THE ORIGINAL (FAULTY) PROGRAM - copied from the question
# ------------------------------------------------------------
def save_returns_old(books):
    log = open("returns.log", "w")
    for b in books:
        log.write(b)
    log.close()


def process_old(day_file):
    try:
        books = open(day_file).read().split("\n")
        save_returns_old(books)
    except FileNotFoundError:
        print("missing")


# ------------------------------------------------------------
# TASK 4.1 - LOCATE THE DEFECTS
# ------------------------------------------------------------
heading("TASK 4.1 - Defects")
print("""
Defect 1 - earlier days are lost
  open("returns.log", "w") uses WRITE mode. Write mode empties the file every
  time it is opened. Each day's call starts with an empty log, so after a week
  only the last day is left. The log needs APPEND mode ("a").

Defect 2 - books are joined together
  log.write(b) writes the text only. write() does not add a new line, so
  "Book A" and "Book B" become "Book ABook B". We must write b + "\\n".
  (Also, split("\\n") gives an empty "" at the end when the file ends with a
  new line, so a blank entry is written.)

Defect 3 - the file stays open when write() fails
  If write() raises an error (disk full, bad data), the line log.close() is
  never reached. The file stays open, and the text still waiting in the
  buffer is not saved. The same happens to open(day_file), which is never
  closed on purpose.

Defect 4 - the error leaves no message
  Only FileNotFoundError is caught, and it only uses print(), so nothing is
  saved. Any other error stops the program and the message is lost with the
  screen. Errors should be written to an error log file.
""")


# ------------------------------------------------------------
# HELPERS FOR THE TESTS
# ------------------------------------------------------------
real_open = builtins.open
opened_logs = []          # every returns.log file object that gets opened


def tracking_open(*args, **kwargs):
    file = real_open(*args, **kwargs)
    if str(args[0]).endswith("returns.log"):
        opened_logs.append(file)
    return file


def fresh_folder():
    """Make an empty temporary folder with three day files and go into it."""
    folder = tempfile.mkdtemp()
    os.chdir(folder)
    opened_logs.clear()
    with real_open("day1.txt", "w") as f:
        f.write("Book A\nBook B\n")
    with real_open("day2.txt", "w") as f:
        f.write("Book C\n")
    with real_open("day3.txt", "w") as f:
        f.write("Book D\nBook E\n")
    return folder


def show(name):
    if os.path.exists(name):
        with real_open(name, encoding="utf-8") as f:
            print(f"{name} contains: {f.read()!r}")
    else:
        print(f"{name} does not exist")


start_folder = os.getcwd()


def remove_folder(folder):
    os.chdir(start_folder)          # Windows cannot delete a folder we are standing in
    shutil.rmtree(folder, ignore_errors=True)


builtins.open = tracking_open


# ------------------------------------------------------------
# TASK 4.2 - CONSTRUCT EVIDENCE (tests on the OLD program)
# ------------------------------------------------------------
heading("TASK 4.2 - Tests that show each defect (OLD program)")

folder = fresh_folder()
for day in ("day1.txt", "day2.txt", "day3.txt"):
    process_old(day)
print("\nDefect 1 + 2: three days processed")
show("returns.log")
print("  -> Book A, Book B, Book C are gone (defect 1).")
print("  -> 'Book D' and 'Book E' are glued together (defect 2).")

print("\nDefect 4: a missing day file")
process_old("day9.txt")
show("errors.log")
print("  -> 'missing' was only printed on the screen. Nothing was saved.")
remove_folder(folder)

folder = fresh_folder()
print("\nDefect 3: write() fails halfway (a None slips into the list)")
try:
    save_returns_old(["Book X", None])
except TypeError as error:
    print("TypeError:", error)
print("Is the log file closed?", opened_logs[-1].closed)
show("returns.log")
print("  -> 'Book X' is not on disk yet, it is stuck in the buffer.")
unclosed_old = sum(1 for f in opened_logs if not f.closed)   # count before we clean up
opened_logs[-1].close()
print("  -> The TypeError is not caught, so the program stopped with no saved message.")
remove_folder(folder)


# ------------------------------------------------------------
# TASK 4.3 - REPAIR THE PROGRAM
# append mode, newline characters, with statements, error log
# ------------------------------------------------------------
heading("TASK 4.3 - Repaired program")


def write_error(message):
    """Save an error message with the time to errors.log."""
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open("errors.log", "a", encoding="utf-8") as error_log:
        error_log.write(f"{stamp}  {message}\n")


def save_returns(books):
    with open("returns.log", "a", encoding="utf-8") as log:   # "a" = append
        for b in books:
            log.write(b + "\n")                               # one book per line


def process(day_file):
    try:
        with open(day_file, encoding="utf-8") as file:
            books = [line.strip() for line in file if line.strip() != ""]
        save_returns(books)
    except FileNotFoundError:
        write_error("missing file: " + day_file)
    except PermissionError:
        write_error("permission denied: " + day_file)
    except UnicodeDecodeError:
        write_error("cannot read (not UTF-8 text): " + day_file)
    except Exception as error:      # last safety net: save the message, then stop loudly
        write_error(f"unexpected {type(error).__name__}: {error} in {day_file}")
        raise


folder = fresh_folder()
for day in ("day1.txt", "day2.txt", "day3.txt"):
    process(day)
print("Three days processed with the repaired program:")
show("returns.log")

process("day9.txt")                                  # missing file
with real_open("day4.txt", "wb") as f:               # file that is not UTF-8
    f.write(b"\xff\xfe\x00")
process("day4.txt")

print("\nA failure while saving (disk full is simulated):")


def disk_full(books):
    raise OSError("disk full")


good_save = save_returns
save_returns = disk_full                              # process() will now call disk_full
try:
    process("day1.txt")
except OSError as error:
    print("Program stopped with:", error)
save_returns = good_save

print("\nA bad value in the middle of writing:")
try:
    save_returns(["Book X", None])
except TypeError as error:
    print("TypeError:", error)
print("Is the log file closed?", opened_logs[-1].closed)
show("returns.log")
print("  -> 'Book X' reached the disk because with closed the file.")

print("\nContents of errors.log:")
with real_open("errors.log", encoding="utf-8") as f:
    print(f.read())
unclosed_with = sum(1 for f in opened_logs if not f.closed)
print("Log files still open:", unclosed_with)
remove_folder(folder)


# ------------------------------------------------------------
# TASK 4.4 - PREVENT RECURRENCE
# ------------------------------------------------------------
heading("TASK 4.4 - Two rules")
print("""
Rule 1: Always open files with a "with" statement (or close them in finally),
        so the file is closed and saved even when an error happens.

Rule 2: Choose the file mode on purpose and write complete records:
        use "a" for a log that keeps growing ("w" erases the old content),
        and end every record with "\\n".
        (Also: catch specific exceptions and save the message to an error log.)
""")


# ------------------------------------------------------------
# ALTERNATIVE CONCEPT - open/close by hand with try/finally
# ------------------------------------------------------------
heading("ALTERNATIVE - try/finally instead of with")


def save_returns_manual(books):
    log = open("returns.log", "a", encoding="utf-8")   # open BEFORE the try
    try:
        for b in books:
            log.write(b + "\n")
    finally:
        log.close()                                    # always runs


folder = fresh_folder()
try:
    save_returns_manual(["Book X", None])
except TypeError as error:
    print("TypeError:", error)
print("Is the log file closed?", opened_logs[-1].closed)
show("returns.log")
unclosed_manual = sum(1 for f in opened_logs if not f.closed)
remove_folder(folder)

print(f"""
Files left open after ONE failing call:
  original program      : {unclosed_old}   (the log file; it grows by one for every failing day)
  with statement        : {unclosed_with}
  try/finally           : {unclosed_manual}

Complexity:
  Time  : O(n) for n books in all three versions (one write per book).
          with / try-finally add only a tiny constant cost for closing the file.
  Space : the same. The books list needs O(n) in all versions; the file
          buffer is a fixed size. (Reading line by line would make it O(1).)
  So the complexity does NOT change. What changes is safety:
  with closes the file automatically, while try/finally works only if the
  open() is placed before the try and close() is placed in finally.
  If someone forgets the finally, or opens the file inside the try and
  closes it after the loop, the leak comes back.
""")

builtins.open = real_open
os.chdir(start_folder)