# __init__.py - marks this folder as a package.
# Nothing is imported here on purpose.
__version__ = "1.0"
