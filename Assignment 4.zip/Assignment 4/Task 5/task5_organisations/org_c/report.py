# report.py - writing reports


def write_summary(path, percentages):
    with open(path, "w", encoding="utf-8") as file:
        file.write("ATTENDANCE SUMMARY\n")
        for student, value in percentages.items():
            file.write(f"{student}: {value}%\n")


def write_absence_report(path, students):
    with open(path, "w", encoding="utf-8") as file:
        file.write("ABSENT 3 DAYS IN A ROW\n")
        if not students:
            file.write("(none)\n")
        for student in students:
            file.write(student + "\n")
