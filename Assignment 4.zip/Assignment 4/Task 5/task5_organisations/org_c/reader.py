# reader.py - reading files
from datetime import datetime


def read_records(path):
    """Read the file and return a list of (student, date, status).
    Damaged lines are skipped."""
    records = []
    with open(path, encoding="utf-8") as file:
        for line in file:
            parts = line.strip().split(",")
            if len(parts) != 3 or parts[2] not in ("P", "A"):
                continue
            try:
                datetime.strptime(parts[1], "%Y-%m-%d")
            except ValueError:
                continue
            records.append((parts[0], parts[1], parts[2]))
    return records
