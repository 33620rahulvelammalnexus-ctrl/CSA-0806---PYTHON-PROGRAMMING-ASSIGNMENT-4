# stats.py - computing statistics
from datetime import datetime, timedelta


def percentage(records):
    """Percentage of P records (0.0 when there are no records)."""
    if not records:
        return 0.0
    present = sum(1 for record in records if record[2] == "P")
    return round(present * 100 / len(records), 1)


def student_percentages(records):
    """{'101': 40.0, '102': 40.0, ...}"""
    by_student = {}
    for record in records:
        by_student.setdefault(record[0], []).append(record)
    return {student: percentage(items) for student, items in sorted(by_student.items())}


def absent_three_days(records):
    """Students absent on three calendar days in a row."""
    absent_days = {}
    for student, date, status in records:
        if status == "A":
            day = datetime.strptime(date, "%Y-%m-%d").date()
            absent_days.setdefault(student, set()).add(day)

    result = []
    for student in sorted(absent_days):
        days = absent_days[student]
        for day in sorted(days):
            if day + timedelta(days=1) in days and day + timedelta(days=2) in days:
                result.append(student)
                break
    return result


if __name__ == "__main__":
    sample = [("1", "2026-10-05", "P"), ("1", "2026-10-06", "A")]
    assert percentage(sample) == 50.0
    three = [("1", "2026-10-0%d" % day, "A") for day in (5, 6, 7)]
    assert absent_three_days(three) == ["1"]
    print("self-test passed")
