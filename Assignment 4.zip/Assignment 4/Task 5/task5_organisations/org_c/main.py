# main.py - the starting point
import reader, stats, report


def main():
    records = reader.read_records("attendance.csv")
    report.write_summary("summary.txt", stats.student_percentages(records))
    report.write_absence_report("absence.txt", stats.absent_three_days(records))
    print("Reports written")


if __name__ == "__main__":
    main()
