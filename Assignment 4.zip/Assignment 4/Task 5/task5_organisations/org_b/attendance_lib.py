# attendance_lib.py - the module (all functions)
from datetime import datetime, timedelta


def read_records(path):
    """Read the file and return a list of (student, date, status).
    Damaged lines are skipped."""
    records = []
    with open(path, encoding="utf-8") as file:
        for line in file:
            parts = line.strip().split(",")
            if len(parts) != 3 or parts[2] not in ("P", "A"):
                continue
            try:
                datetime.strptime(parts[1], "%Y-%m-%d")
            except ValueError:
                continue
            records.append((parts[0], parts[1], parts[2]))
    return records


def percentage(records):
    """Percentage of P records (0.0 when there are no records)."""
    if not records:
        return 0.0
    present = sum(1 for record in records if record[2] == "P")
    return round(present * 100 / len(records), 1)


def student_percentages(records):
    """{'101': 40.0, '102': 40.0, ...}"""
    by_student = {}
    for record in records:
        by_student.setdefault(record[0], []).append(record)
    return {student: percentage(items) for student, items in sorted(by_student.items())}


def absent_three_days(records):
    """Students absent on three calendar days in a row."""
    absent_days = {}
    for student, date, status in records:
        if status == "A":
            day = datetime.strptime(date, "%Y-%m-%d").date()
            absent_days.setdefault(student, set()).add(day)

    result = []
    for student in sorted(absent_days):
        days = absent_days[student]
        for day in sorted(days):
            if day + timedelta(days=1) in days and day + timedelta(days=2) in days:
                result.append(student)
                break
    return result


def write_summary(path, percentages):
    with open(path, "w", encoding="utf-8") as file:
        file.write("ATTENDANCE SUMMARY\n")
        for student, value in percentages.items():
            file.write(f"{student}: {value}%\n")


def write_absence_report(path, students):
    with open(path, "w", encoding="utf-8") as file:
        file.write("ABSENT 3 DAYS IN A ROW\n")
        if not students:
            file.write("(none)\n")
        for student in students:
            file.write(student + "\n")


if __name__ == "__main__":
    sample = [("1", "2026-10-05", "P"), ("1", "2026-10-06", "A")]
    assert percentage(sample) == 50.0
    three = [("1", "2026-10-0%d" % day, "A") for day in (5, 6, 7)]
    assert absent_three_days(three) == ["1"]
    print("self-test passed")
