# main_b.py - imports the module
import attendance_lib as lib


def main():
    records = lib.read_records("attendance.csv")
    lib.write_summary("summary.txt", lib.student_percentages(records))
    lib.write_absence_report("absence.txt", lib.absent_three_days(records))
    print("Reports written")


if __name__ == "__main__":
    main()
