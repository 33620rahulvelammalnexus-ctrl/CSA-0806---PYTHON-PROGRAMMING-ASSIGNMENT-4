# TASK 5 - THE SAME UTILITY ORGANISED FOUR WAYS
# Run:  python task5_four_organisations.py
# It creates the four organisations as real files in a folder called
# task5_organisations (next to this script), runs each one, adds the second
# report to each one, and prints the evidence.

import hashlib
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "task5_organisations")


def heading(text):
    print("\n" + "=" * 66)
    print(text)
    print("=" * 66)


# ------------------------------------------------------------
# THE CODE PIECES (the same functions are used in all four ways)
# ------------------------------------------------------------
DATA = """101,2026-10-05,P
101,2026-10-06,A
101,2026-10-07,A
101,2026-10-08,A
101,2026-10-09,P
102,2026-10-05,A
102,2026-10-06,P
102,2026-10-07,A
102,2026-10-08,P
102,2026-10-09,A
103,2026-10-05,P
103,2026-10-06,P
103,2026-10-07,P
103,2026-10-08,A
103,2026-10-09,A
this line is damaged
104,2026-10-31,X
"""

READER_BODY = r'''def read_records(path):
    """Read the file and return a list of (student, date, status).
    Damaged lines are skipped."""
    records = []
    with open(path, encoding="utf-8") as file:
        for line in file:
            parts = line.strip().split(",")
            if len(parts) != 3 or parts[2] not in ("P", "A"):
                continue
            try:
                datetime.strptime(parts[1], "%Y-%m-%d")
            except ValueError:
                continue
            records.append((parts[0], parts[1], parts[2]))
    return records
'''

STATS_BODY_V1 = r'''def percentage(records):
    """Percentage of P records (0.0 when there are no records)."""
    if not records:
        return 0.0
    present = sum(1 for record in records if record[2] == "P")
    return round(present * 100 / len(records), 1)


def student_percentages(records):
    """{'101': 40.0, '102': 40.0, ...}"""
    by_student = {}
    for record in records:
        by_student.setdefault(record[0], []).append(record)
    return {student: percentage(items) for student, items in sorted(by_student.items())}
'''

STATS_EXTRA_V2 = r'''

def absent_three_days(records):
    """Students absent on three calendar days in a row."""
    absent_days = {}
    for student, date, status in records:
        if status == "A":
            day = datetime.strptime(date, "%Y-%m-%d").date()
            absent_days.setdefault(student, set()).add(day)

    result = []
    for student in sorted(absent_days):
        days = absent_days[student]
        for day in sorted(days):
            if day + timedelta(days=1) in days and day + timedelta(days=2) in days:
                result.append(student)
                break
    return result
'''

REPORT_BODY_V1 = r'''def write_summary(path, percentages):
    with open(path, "w", encoding="utf-8") as file:
        file.write("ATTENDANCE SUMMARY\n")
        for student, value in percentages.items():
            file.write(f"{student}: {value}%\n")
'''

REPORT_EXTRA_V2 = r'''

def write_absence_report(path, students):
    with open(path, "w", encoding="utf-8") as file:
        file.write("ABSENT 3 DAYS IN A ROW\n")
        if not students:
            file.write("(none)\n")
        for student in students:
            file.write(student + "\n")
'''


def stats_body(v2):
    return STATS_BODY_V1 + (STATS_EXTRA_V2 if v2 else "")


def report_body(v2):
    return REPORT_BODY_V1 + (REPORT_EXTRA_V2 if v2 else "")


def selftest_lines(v2):
    lines = ['sample = [("1", "2026-10-05", "P"), ("1", "2026-10-06", "A")]',
             'assert percentage(sample) == 50.0']
    if v2:
        lines += ['three = [("1", "2026-10-0%d" % day, "A") for day in (5, 6, 7)]',
                  'assert absent_three_days(three) == ["1"]']
    lines.append('print("self-test passed")')
    return lines


def guard(lines):
    return 'if __name__ == "__main__":\n' + "".join("    " + line + "\n" for line in lines)


def datetime_import(v2):
    return "from datetime import datetime, timedelta\n" if v2 else "from datetime import datetime\n"


# ------------------------------------------------------------
# TASK 5.1 - BUILD THE FOUR ORGANISATIONS
# ------------------------------------------------------------
def build(org, v2):
    """Return {relative path: file text} for one organisation."""
    files = {"attendance.csv": DATA}

    if org == "a":          # (a) ONE SCRIPT
        main_part = ['def main():',
                     '    records = read_records("attendance.csv")',
                     '    write_summary("summary.txt", student_percentages(records))']
        if v2:
            main_part.append('    write_absence_report("absence.txt", absent_three_days(records))')
        main_part.append('    print("Reports written")')
        text = ("# attendance_a.py - everything in ONE script\n"
                + datetime_import(v2) + "\n\n"
                + READER_BODY + "\n\n" + stats_body(v2) + "\n\n" + report_body(v2) + "\n\n"
                + "\n".join(main_part) + "\n\n\n"
                + guard(["main()"]))
        files["attendance_a.py"] = text

    if org == "b":          # (b) ONE MODULE + MAIN SCRIPT
        text = ("# attendance_lib.py - the module (all functions)\n"
                + datetime_import(v2) + "\n\n"
                + READER_BODY + "\n\n" + stats_body(v2) + "\n\n" + report_body(v2) + "\n\n"
                + guard(selftest_lines(v2)))
        files["attendance_lib.py"] = text
        main_part = ['import attendance_lib as lib', '', '',
                     'def main():',
                     '    records = lib.read_records("attendance.csv")',
                     '    lib.write_summary("summary.txt", lib.student_percentages(records))']
        if v2:
            main_part.append('    lib.write_absence_report("absence.txt", lib.absent_three_days(records))')
        main_part.append('    print("Reports written")')
        files["main_b.py"] = ("# main_b.py - imports the module\n" + "\n".join(main_part)
                              + "\n\n\n" + guard(["main()"]))

    if org in ("c", "d"):   # (c) THREE MODULES IN A FOLDER / (d) PACKAGE
        prefix = "" if org == "c" else "attendance/"
        files[prefix + "reader.py"] = ("# reader.py - reading files\nfrom datetime import datetime\n\n\n"
                                       + READER_BODY)
        files[prefix + "stats.py"] = ("# stats.py - computing statistics\n"
                                      + (datetime_import(True) + "\n\n" if v2 else "\n")
                                      + stats_body(v2) + "\n\n" + guard(selftest_lines(v2)))
        files[prefix + "report.py"] = "# report.py - writing reports\n\n\n" + report_body(v2)
        if org == "d":
            files["attendance/__init__.py"] = ('# __init__.py - marks this folder as a package.\n'
                                               '# Nothing is imported here on purpose.\n'
                                               '__version__ = "1.0"\n')
        import_line = "import reader, stats, report" if org == "c" else "from attendance import reader, stats, report"
        main_part = [import_line, '', '', 'def main():',
                     '    records = reader.read_records("attendance.csv")',
                     '    report.write_summary("summary.txt", stats.student_percentages(records))']
        if v2:
            main_part.append('    report.write_absence_report("absence.txt", stats.absent_three_days(records))')
        main_part.append('    print("Reports written")')
        files["main.py"] = ("# main.py - the starting point\n" + "\n".join(main_part)
                            + "\n\n\n" + guard(["main()"]))
    return files


MAIN_FILE = {"a": "attendance_a.py", "b": "main_b.py", "c": "main.py", "d": "main.py"}
NAMES = {"a": "(a) one script", "b": "(b) one module + main", "c": "(c) three modules in a folder",
         "d": "(d) package attendance/"}


def write_files(org, files):
    folder = os.path.join(ROOT, "org_" + org)
    for relative, text in files.items():
        full = os.path.join(folder, *relative.split("/"))
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w", encoding="utf-8") as file:
            file.write(text)
    return folder


def run_org(org):
    folder = os.path.join(ROOT, "org_" + org)
    result = subprocess.run([sys.executable, MAIN_FILE[org]], cwd=folder,
                            capture_output=True, text=True)
    if result.returncode != 0:
        print("ERROR in organisation", org)
        print(result.stderr)
        sys.exit(1)
    outputs = {}
    for name in ("summary.txt", "absence.txt"):
        path = os.path.join(folder, name)
        if os.path.exists(path):
            with open(path, encoding="utf-8") as file:
                outputs[name] = file.read()
    return outputs


def show_tree(org):
    folder = os.path.join(ROOT, "org_" + org)
    for current, dirs, names in os.walk(folder):
        dirs[:] = sorted(d for d in dirs if d != "__pycache__")
        level = os.path.relpath(current, folder).count(os.sep) + (0 if current == folder else 1)
        if current != folder:
            print("   " * level + os.path.basename(current) + "/")
        for name in sorted(names):
            if name.endswith(".py"):
                print("   " * (level + 1) + name)


shutil.rmtree(ROOT, ignore_errors=True)

heading("TASK 5.1 - Four organisations (version 1: one report)")
version1, outputs1 = {}, {}
for org in "abcd":
    version1[org] = build(org, v2=False)
    write_files(org, version1[org])
    outputs1[org] = run_org(org)
    print(f"\n{NAMES[org]}")
    show_tree(org)
print("\nsummary.txt produced by organisation (a):")
print(outputs1["a"]["summary.txt"])
same = all(outputs1[o]["summary.txt"] == outputs1["a"]["summary.txt"] for o in "bcd")
print("All four organisations give the same summary.txt:", same)


# ------------------------------------------------------------
# TASK 5.2 - CHANGE THE REQUIREMENT
# ------------------------------------------------------------
heading("TASK 5.2 - Add the second report (absent 3 days in a row)")
changed_counts = {}
outputs2 = {}
for org in "abcd":
    version2 = build(org, v2=True)
    changed = [name for name in version2 if version2[name] != version1[org].get(name)]
    changed_counts[org] = len(changed)
    write_files(org, version2)
    outputs2[org] = run_org(org)
    print(f"{NAMES[org]:<32} files changed: {len(changed)}  -> {', '.join(changed)}")
print("\nabsence.txt produced by organisation (d):")
print(outputs2["d"]["absence.txt"])
same = all(outputs2[o] == outputs2["a"] for o in "bcd")
print("All four organisations give the same two reports:", same)
print("Reader file changed in (c) and (d)?  No - only the files that own the new logic changed.")


# ------------------------------------------------------------
# TASK 5.3 - COMPARE THE ORGANISATIONS
# ------------------------------------------------------------
heading("TASK 5.3 - Comparison")
print("""
                 | Readability      | Reuse              | Testing             | Naming conflicts
-----------------+------------------+--------------------+---------------------+---------------------
(a) one script   | easy while short;| copy and paste only| run the whole script| all names share one
                 | hard when long   |                    | or edit it          | space (clashes easy)
(b) one module   | main is short;   | any script can     | test the module     | one space inside the
                 | module still big | import the module  | alone               | module; module.name
(c) 3 modules    | each file has one| reader, stats or   | test each file      | one space per file;
                 | job              | report separately  | separately          | name clash between
                 |                  |                    |                     | folders possible
(d) package      | same as (c) plus | whole package can  | each sub-module     | names live under
                 | clear structure  | be installed/shared| alone; package test | attendance.xxx
""")

print("Naming conflict, shown with real code:")
one_file = "def write(path, data): return 'summary'\ndef write(path, data): return 'absence'\n"
space = {}
exec(one_file, space)
print("  one script, two functions called write -> write() gives:", space["write"]("x", []),
      "(the first one was replaced silently)")
space1, space2 = {}, {}
exec("def write(path, data): return 'summary'\n", space1)
exec("def write(path, data): return 'absence'\n", space2)
print("  two modules, each with write()          ->", space1["write"]("x", []), "and", space2["write"]("x", []),
      "(both survive: summary.write and absence.write)")

print("\nThe three import forms (run in the package folder, names that exist afterwards):")
for statement in ("import attendance.stats",
                  "from attendance import stats",
                  "from attendance.stats import percentage"):
    code = (statement + "\nprint([n for n in dir() if not n.startswith('_')])")
    result = subprocess.run([sys.executable, "-c", code], cwd=os.path.join(ROOT, "org_d"),
                            capture_output=True, text=True)
    print(f"  {statement:<42} -> {result.stdout.strip()}")
print("""
  import attendance.stats                 : loads the package and stats, but the only name you get is
                                            'attendance'. You must write attendance.stats.percentage(...).
  from attendance import stats            : you get the name 'stats' (the module). You write
                                            stats.percentage(...). Short, and the origin stays visible.
  from attendance.stats import percentage : you get only the function name 'percentage'. Shortest,
                                            but a later 'percentage' from another place replaces it
                                            silently, and the reader cannot see where it came from.
  All three load stats.py once and keep it in sys.modules.""")


# ------------------------------------------------------------
# ALTERNATIVE CONCEPT - everything in one script, import cost, memory,
# effort to find and change a function
# ------------------------------------------------------------
heading("ALTERNATIVE - one script instead of a package: cost analysis")
print("Organisation (a) above IS the one-script solution:", os.path.join(ROOT, "org_a", "attendance_a.py"))

IMPORTS = {"a": "import attendance_a",
           "b": "import attendance_lib",
           "c": "import reader, stats, report",
           "d": "import attendance.reader, attendance.stats, attendance.report"}


def measure(org):
    folder = os.path.join(ROOT, "org_" + org)
    stmt = IMPORTS[org]
    time_code = ("import sys, time\nbefore = len(sys.modules)\n"
                 f"t = time.perf_counter()\n{stmt}\nfirst = time.perf_counter() - t\n"
                 f"t = time.perf_counter()\n{stmt}\nagain = time.perf_counter() - t\n"
                 "print(first * 1000, again * 1000000, len(sys.modules) - before)")
    memory_code = ("import tracemalloc\ntracemalloc.start()\n" + stmt +
                   "\nprint(tracemalloc.get_traced_memory()[0] / 1024)")
    best = None
    for _ in range(7):                       # the first run also creates the .pyc cache
        out = subprocess.run([sys.executable, "-c", time_code], cwd=folder,
                             capture_output=True, text=True).stdout.split()
        values = [float(x) for x in out]
        if best is None or values[0] < best[0]:
            best = values
    memory = float(subprocess.run([sys.executable, "-c", memory_code], cwd=folder,
                                  capture_output=True, text=True).stdout)
    return best, memory


print(f"\n{'organisation':<32}{'first import':>14}{'2nd import':>13}{'new modules':>14}{'memory':>10}")
print(f"{'':<32}{'(ms)':>14}{'(microsec)':>13}{'in sys.modules':>15}{'(KB)':>10}")
for org in "abcd":
    (first, again, modules), memory = measure(org)
    print(f"{NAMES[org]:<32}{first:>14.2f}{again:>13.1f}{int(modules):>15}{memory:>10.1f}")

print("\nEffort to find and change a function (after the second report was added):")
print(f"{'organisation':<32}{'py files':>9}{'total lines':>13}{'lines in the file':>19}{'files changed':>15}")
print(f"{'':<32}{'':>9}{'':>13}{'holding percentage()':>19}{'for report 2':>15}")
for org in "abcd":
    folder = os.path.join(ROOT, "org_" + org)
    total, holder, count = 0, 0, 0
    for current, dirs, names in os.walk(folder):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for name in names:
            if name.endswith(".py"):
                count += 1
                with open(os.path.join(current, name), encoding="utf-8") as file:
                    lines = file.read().splitlines()
                total += len(lines)
                if any(line.startswith("def percentage") for line in lines):
                    holder = len(lines)
    print(f"{NAMES[org]:<32}{count:>9}{total:>13}{holder:>19}{changed_counts[org]:>15}")

print("""
Reading the numbers:
 - A package is loaded ONCE. The first import runs the files, finds them, compiles them if needed and
   stores each module in sys.modules. Every later import only looks the name up in sys.modules, which
   is why the second import is over a thousand times faster. Nothing is loaded again.
 - The package costs a little more time and memory at the first import than one script because there
   are more files to find and more module objects, but the difference is small (milliseconds, a few KB)
   and it is paid only once per program run.
 - Finding a function: in one script you search one long file; in a package you go straight to the
   file whose name matches the job (stats.py). Changing it touches only the files that own that
   job (plus main). The number of files changed is larger for (c) and (d), but each file is small and
   the reader was never touched. For a tiny program, one script is the simplest; as the program
   grows, the package wins on finding, testing and reuse.
 (The numbers depend on your computer. The ones above come from your own run.)""")

# tidy up the cache folders created by the measurements
for current, dirs, names in os.walk(ROOT):
    for d in list(dirs):
        if d == "__pycache__":
            shutil.rmtree(os.path.join(current, d), ignore_errors=True)
            dirs.remove(d)