# TASK 3 - DESIGN THE ERROR HANDLING (Attendance Processor)
# Run:  python task3_attendance_error_handling.py

import os
import tempfile
import time
from datetime import datetime


def heading(text):
    print("\n" + "=" * 60)
    print(text)
    print("=" * 60)


# ------------------------------------------------------------
# TASK 3.1 - IDENTIFY THE FAILURES
# ------------------------------------------------------------
heading("TASK 3.1 - Failure table")

failures = [
    ("Folder does not exist",           "FileNotFoundError"),
    ("File does not exist",             "FileNotFoundError"),
    ("Path is a folder, not a file",    "IsADirectoryError (PermissionError on Windows)"),
    ("Permission denied",               "PermissionError"),
    ("Wrong encoding (not UTF-8)",      "UnicodeDecodeError (a kind of ValueError)"),
    ("Damaged line (wrong field count)", "InvalidRecord (built-in: ValueError / IndexError)"),
    ("Status is not P or A",            "InvalidRecord"),
    ("Student number is not a number",  "ValueError (from int())"),
    ("Date is not valid",               "ValueError (from strptime())"),
    ("Disk / read error",               "OSError"),
    ("Empty file",                      "No exception - result is (0, 0, [])"),
]
for problem, exception in failures:
    print(f"{problem:<36} -> {exception}")


# ------------------------------------------------------------
# TASK 3.2 - CUSTOM EXCEPTION
# Raised in parse_line() (where one line is checked).
# Handled in summarise() (around each line, so one bad line
# does not stop the whole file).
# ------------------------------------------------------------
heading("TASK 3.2 - Custom exception InvalidRecord")


class InvalidRecord(Exception):
    """Raised when a line of the attendance file is not in the expected format."""


def parse_line(line):
    """'192311001,2026-10-08,P' -> ('192311001', '2026-10-08', 'P')"""
    parts = line.strip().split(",")

    # TODO 1: wrong number of fields or wrong status -> InvalidRecord
    if len(parts) != 3:
        raise InvalidRecord(f"expected 3 fields, found {len(parts)}")
    student, date, status = parts
    if status not in ("P", "A"):
        raise InvalidRecord(f"invalid status '{status}'")

    # int() and strptime() raise ValueError. "raise ... from ..." keeps that cause.
    try:
        int(student)
        datetime.strptime(date, "%Y-%m-%d")
    except ValueError as error:
        raise InvalidRecord(f"bad student number or date in '{line.strip()}'") from error
    return student, date, status


# ------------------------------------------------------------
# TASK 3.3 - COMPLETE try STATEMENT
# try / specific except / else / finally / raise ... from ...
# ------------------------------------------------------------
def summarise(path):
    present, absent, errors = 0, 0, []

    # TODO 2
    try:
        with open(path, encoding="utf-8") as file:
            for number, line in enumerate(file, start=1):
                try:
                    student, date, status = parse_line(line)
                except InvalidRecord as problem:     # bad line: record it, carry on
                    errors.append((number, str(problem)))
                else:                                # runs only if the line was good
                    if status == "P":
                        present += 1
                    else:
                        absent += 1
    except FileNotFoundError:
        errors.append((0, "file or folder not found: " + path))
    except PermissionError:
        errors.append((0, "permission denied: " + path))
    except IsADirectoryError:
        errors.append((0, "this is a folder, not a file: " + path))
    except UnicodeDecodeError as error:
        raise InvalidRecord("file is not valid UTF-8 text") from error
    finally:                                         # always runs, error or not
        summarise.runs += 1

    return present, absent, errors


summarise.runs = 0

heading("TASK 3.3 - Run the program (expected output test)")
data = ("192311001,2026-10-08,P\n192311002,2026-10-08,A\n"
        "192311003,2026-10-08\n192311004,2026-10-08,L\n")
with tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False,
                                 encoding="utf-8") as tmp:
    tmp.write(data)
print(summarise(tmp.name))
os.remove(tmp.name)

print("\nMissing file name:")
print(summarise("no_such_file.csv"))

print("\nMissing folder:")
print(summarise("no_folder/attendance.csv"))

print("\nPath is a folder:")
print(summarise(tempfile.gettempdir()))

print("\nEmpty file:")
empty = tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False)
empty.close()
print(summarise(empty.name))
os.remove(empty.name)

print("\nWrong encoding (raise ... from ...):")
bad = tempfile.NamedTemporaryFile("wb", suffix=".csv", delete=False)
bad.write(b"192311001,2026-10-08,P\n\xff\xfe\x00bad\n")
bad.close()
try:
    summarise(bad.name)
except InvalidRecord as error:
    print("InvalidRecord:", error, "| original cause:", type(error.__cause__).__name__)
os.remove(bad.name)

print("\nBad student number (raise ... from ...):")
try:
    parse_line("19x,2026-10-08,P")
except InvalidRecord as error:
    print("InvalidRecord:", error)
    print("original cause:", repr(error.__cause__))

print("\nfinally block ran", summarise.runs, "times")


# ------------------------------------------------------------
# TASK 3.4 - MISUSE EXPERIMENT
# Specific excepts replaced by "except Exception: pass" and a typing
# error (presnt instead of present) added on purpose.
# ------------------------------------------------------------
heading("TASK 3.4 - Misuse experiment")


def summarise_misuse(path):
    present, absent, errors = 0, 0, []
    try:
        with open(path, encoding="utf-8") as file:
            for number, line in enumerate(file, start=1):
                student, date, status = parse_line(line)
                if status == "P":
                    presnt += 1          # TYPING ERROR: should be present
                else:
                    absent += 1
    except Exception:
        pass                             # hides EVERYTHING
    return present, absent, errors


with tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False,
                                 encoding="utf-8") as tmp:
    tmp.write(data)
print("Misuse version, file with 1 P, 1 A, 2 bad lines:", summarise_misuse(tmp.name))
print("Correct answer should be                       :", summarise(tmp.name))
os.remove(tmp.name)
print("Misuse version, missing file                   :", summarise_misuse("no_such_file.csv"))
print("""
Why the error is hidden:
 - The typo makes Python raise UnboundLocalError (a kind of NameError) on the first P line.
 - "except Exception: pass" catches it and does nothing, so no message and no traceback.
 - The same clause also hides the bad lines and the missing file.
 - Result: a silent WRONG answer, which is worse than a crash.""")


# ------------------------------------------------------------
# ALTERNATIVE CONCEPT - LOOK BEFORE YOU LEAP (if checks) vs
# EASIER TO ASK FORGIVENESS (try/except)
# ------------------------------------------------------------
heading("ALTERNATIVE - LBYL (if) vs EAFP (try/except) timing")


def check_line(line):
    parts = line.split(",")
    if len(parts) != 3:
        raise InvalidRecord("fields")
    if parts[2] not in ("P", "A"):
        raise InvalidRecord("status")
    return parts


def count_with_try(lines):
    present = absent = errors = 0
    for line in lines:
        try:
            parts = check_line(line)
        except InvalidRecord:
            errors += 1
        else:
            if parts[2] == "P":
                present += 1
            else:
                absent += 1
    return present, absent, errors


def count_with_if(lines):
    present = absent = errors = 0
    for line in lines:
        parts = line.split(",")
        if len(parts) == 3 and parts[2] in ("P", "A"):
            if parts[2] == "P":
                present += 1
            else:
                absent += 1
        else:
            errors += 1
    return present, absent, errors


good_line = "192311001,2026-10-08,P"
bad_line = "192311003,2026-10-08"
total = 200000
print(f"{'bad lines':>10} | {'try/except (ns/line)':>21} | {'if-check (ns/line)':>19}")
for percent in (0, 1, 10, 50, 100):
    bad_count = total * percent // 100
    lines = [bad_line] * bad_count + [good_line] * (total - bad_count)
    assert count_with_try(lines) == count_with_if(lines)     # same answer
    times = []
    for function in (count_with_try, count_with_if):
        start = time.perf_counter()
        function(lines)
        times.append((time.perf_counter() - start) / total * 1e9)
    print(f"{percent:>9}% | {times[0]:>21.0f} | {times[1]:>19.0f}")

print("""
Both styles do constant work per line, so the whole file is O(n).
 - Bad lines rare  : almost the same speed (try costs almost nothing).
 - Bad lines common: raising an exception is slower (object creation + unwinding);
                     the if-check stays the same. Use if-checks when most data is bad,
                     exceptions when bad data is the exception.
 (Times depend on your computer - quote the numbers from your own run.)""")