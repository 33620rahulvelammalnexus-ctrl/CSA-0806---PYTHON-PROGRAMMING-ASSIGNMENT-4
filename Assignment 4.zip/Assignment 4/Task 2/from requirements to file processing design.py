# =====================================================================
# TASK 2: Biometric Attendance Files - single program, task by task
# Run it directly. It creates sample daily files, processes them and
# writes the two output files.
# =====================================================================

from pathlib import Path
from datetime import datetime


# #####################################################################
# ##                                                                 ##
# ##   TASK 2.1 - MODEL THE DATA (2 Marks)                           ##
# ##                                                                 ##
# #####################################################################
#
# INPUT FILES (one text file per day, in one folder per month)
#   File name : attendance_YYYY-MM-DD.txt   (example: attendance_2026-10-01.txt)
#   Each line : REGISTER_NO,DATE,STATUS     (example: 101,2026-10-01,P)
#   Valid line: exactly 3 fields, register number not empty,
#               date in YYYY-MM-DD form, status is P or A.
#   Damaged   : missing fields, empty register number, bad date,
#               status other than P or A. (Empty lines are just skipped.)
#
# DATA STRUCTURES
#   total   = {}   dictionary: register number -> days counted (P + A)
#   present = {}   dictionary: register number -> days present (P)
#   damaged = []   list of tuples (file name, line number, line text, reason)
#   Percentage = present * 100 / total   (worked out when writing the report)
#
# OUTPUT FILES
#   1. attendance_report.txt
#        header line, then one row per student:
#        Reg No | Present | Total | Percent
#        then a section "Students below 75%:" listing register number and percent
#   2. damaged_lines.log
#        one line per damaged record:
#        file name | line number | reason | original line text

def create_sample_files(folder_name):
    """Task 2.1 - creates 3 daily files in the input format described above."""
    Path(folder_name).mkdir(exist_ok=True)

    with open(Path(folder_name) / "attendance_2026-10-01.txt", "w",
              encoding="utf-8") as f:
        f.write("101,2026-10-01,P\n")
        f.write("102,2026-10-01,A\n")
        f.write("103,2026-10-01,P\n")
        f.write("104,2026-10-01,X\n")            # wrong status letter

    with open(Path(folder_name) / "attendance_2026-10-02.txt", "w",
              encoding="utf-8") as f:
        f.write("101,2026-10-02,P\n")
        f.write("102,2026-10-02,P\n")
        f.write("103,2026-10-02,A\n")
        f.write("104,2026-10-02\n")               # missing field

    with open(Path(folder_name) / "attendance_2026-10-03.txt", "w",
              encoding="utf-8") as f:
        f.write("101,2026-10-03,P\n")
        f.write("102,2026-10-03,A\n")
        f.write("103,2026-10-03,A\n")
        f.write("104,2026-10-03,P\n")
        f.write("\n")                             # empty last line


# #####################################################################
# ##                                                                 ##
# ##   TASK 2.2 - DESIGN THE FILE OPERATIONS (2 Marks)               ##
# ##                                                                 ##
# #####################################################################
#
# Read daily files : mode "r", encoding "utf-8", with "for line in f"
#   (iteration reads one line at a time, so memory stays small, and
#    enumerate() gives the line number for the log).
#   Not read() or readlines(), because they load the whole file.
#   Not readline() in a loop, because iteration is simpler and does the same.
# Write the 2 outputs : mode "w", encoding "utf-8", with f.write()
#   Mode "w" gives a fresh report each run. Mode "a" would add the same
#   rows again if the program is run twice.
# "with" closes every file automatically, even after an error.
# pathlib (Path.glob) lists the daily files; sorted() gives date order.

def write_reports(present, total, damaged, report_name, log_name):
    """Task 2.2 - write the attendance report and the damaged log (mode 'w')."""
    low_list = []

    with open(report_name, "w", encoding="utf-8") as out:
        out.write("ATTENDANCE REPORT\n")
        out.write(f"{'Reg No':<10}{'Present':>8}{'Total':>8}{'Percent':>10}\n")
        for reg_no in sorted(total):
            percent = present[reg_no] * 100 / total[reg_no]
            out.write(f"{reg_no:<10}{present[reg_no]:>8}{total[reg_no]:>8}"
                      f"{percent:>10.2f}\n")
            if percent < 75:
                low_list.append((reg_no, percent))

        out.write("\nStudents below 75%:\n")
        if len(low_list) == 0:
            out.write("None\n")
        for reg_no, percent in low_list:
            out.write(f"{reg_no} - {percent:.2f}%\n")

    with open(log_name, "w", encoding="utf-8") as log:
        log.write("DAMAGED LINES LOG\n")
        if len(damaged) == 0:
            log.write("No damaged lines\n")
        for file_name, line_no, text, reason in damaged:
            log.write(f"{file_name} | line {line_no} | {reason} | {text}\n")


def show_file(file_name):
    """Task 2.2 - read a whole small file (mode 'r') to display it."""
    with open(file_name, "r", encoding="utf-8") as f:
        print(f.read(), end="")


# #####################################################################
# ##                                                                 ##
# ##   TASK 2.3 - DESIGN THE PROCESSING (3 Marks)                    ##
# ##                                                                 ##
# #####################################################################
#
# PSEUDOCODE
# BEGIN ProcessMonth(folder_name)
#   SET total   TO empty dictionary
#   SET present TO empty dictionary
#   SET damaged TO empty list
#   SET file_list TO sorted list of attendance_*.txt files in folder_name
#   FOR EACH file IN file_list DO
#       OPEN file for reading
#       SET line_no TO 0
#       FOR EACH line IN file DO
#           INCREMENT line_no
#           REMOVE spaces and newline from line
#           IF line is empty THEN
#               CONTINUE with next line
#           END IF
#           SPLIT line at commas INTO parts
#           IF number of parts is not 3 THEN
#               ADD (file name, line_no, line, "Expected 3 fields") TO damaged
#               CONTINUE with next line
#           END IF
#           SET reg_no TO parts[1], date TO parts[2], status TO parts[3]
#           IF reg_no is empty OR date is not valid OR status is not "P" or "A" THEN
#               ADD (file name, line_no, line, reason) TO damaged
#               CONTINUE with next line
#           END IF
#           total[reg_no]   = total[reg_no] + 1      (start at 0)
#           IF status = "P" THEN
#               present[reg_no] = present[reg_no] + 1
#           END IF
#       END FOR
#       CLOSE file
#   END FOR
#   OPEN report file for writing
#   FOR EACH reg_no IN sorted keys of total DO
#       SET percent TO present[reg_no] * 100 / total[reg_no]
#       WRITE reg_no, present, total, percent
#       IF percent < 75 THEN ADD reg_no to low list
#   END FOR
#   WRITE the low list under "Students below 75%"
#   CLOSE report file
#   OPEN log file for writing
#   FOR EACH record IN damaged DO WRITE file name, line number, reason, line
#   CLOSE log file
# END ProcessMonth

def check_line(line):
    """Task 2.3 - check one line. Returns (reg_no, status, error_message).
    error_message is None when the line is good."""
    parts = line.split(",")
    if len(parts) != 3:
        return None, None, "Expected 3 fields"

    reg_no = parts[0].strip()
    date_text = parts[1].strip()
    status = parts[2].strip()

    if reg_no == "":
        return None, None, "Missing register number"

    try:
        datetime.strptime(date_text, "%Y-%m-%d")
    except ValueError:
        return None, None, "Invalid date"

    if status not in ("P", "A"):
        return None, None, "Status must be P or A"

    return reg_no, status, None


def process_month(folder_name):
    """Task 2.3 - read every file once, accumulate in dictionaries.
    Returns: present, total, damaged, lines_read"""
    folder = Path(folder_name)
    if not folder.is_dir():
        raise FileNotFoundError(folder_name)

    present = {}
    total = {}
    damaged = []                  # (file name, line number, line, reason)
    lines_read = 0

    for file_path in sorted(folder.glob("attendance_*.txt")):
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                for line_no, line in enumerate(f, start=1):
                    lines_read += 1
                    line = line.strip()
                    if line == "":                 # skip empty lines
                        continue

                    reg_no, status, error = check_line(line)
                    if error is not None:
                        damaged.append((file_path.name, line_no, line, error))
                        continue

                    total[reg_no] = total.get(reg_no, 0) + 1
                    if status == "P":
                        present[reg_no] = present.get(reg_no, 0) + 1
                    else:
                        present[reg_no] = present.get(reg_no, 0)
        except (PermissionError, UnicodeDecodeError):
            damaged.append((file_path.name, 0, "", "File could not be read"))

    return present, total, damaged, lines_read


# #####################################################################
# ##                                                                 ##
# ##   TASK 2.4 - TRACE (1 Mark)                                     ##
# ##                                                                 ##
# #####################################################################
#
# Trace of file attendance_2026-10-02.txt, starting with empty
# dictionaries. This function prints the trace step by step.
#
# Expected trace:
# Line 1  101,2026-10-02,P  valid    total={101:1}                  present={101:1}
# Line 2  102,2026-10-02,P  valid    total={101:1,102:1}            present={101:1,102:1}
# Line 3  103,2026-10-02,A  valid    total={101:1,102:1,103:1}      present={101:1,102:1,103:0}
# Line 4  104,2026-10-02    damaged  only 2 fields -> added to the log,
#                                    total and present do not change.

def trace_one_file(file_path):
    """Task 2.4 - process ONE file and print every step."""
    total = {}
    present = {}
    damaged = []

    print("File:", file_path.name)
    with open(file_path, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, start=1):
            line = line.strip()
            if line == "":
                continue

            reg_no, status, error = check_line(line)
            if error is not None:
                damaged.append((file_path.name, line_no, line, error))
                print(f"Line {line_no}: {line} -> DAMAGED ({error})")
                print("        total and present do not change")
                continue

            total[reg_no] = total.get(reg_no, 0) + 1
            if status == "P":
                present[reg_no] = present.get(reg_no, 0) + 1
            else:
                present[reg_no] = present.get(reg_no, 0)

            print(f"Line {line_no}: {line} -> valid")
            print(f"        total={total}  present={present}")

    print("Damaged log entries:", len(damaged))
    for reg_no in sorted(total):
        percent = present[reg_no] * 100 / total[reg_no]
        print(f"{reg_no} -> {present[reg_no]}/{total[reg_no]} = {percent:.2f}%")


# #####################################################################
# ##                                                                 ##
# ##   ALTERNATIVE CONCEPT AND COMPLEXITY ANALYSIS                   ##
# ##                                                                 ##
# #####################################################################
#
# Alternative: for EACH student, re-read ALL daily files and count only
# that student's lines (function reread_for_student below).
#   s = students, f = files, l = lines per file
#   Dictionary method : every line read once    -> time O(f*l)
#   Re-reading method : every line read s times -> time O(s*f*l)
#   Space (dictionary): O(s) for the two dictionaries (+ damaged list)
#   Space (re-reading): O(1) extra per student (two counters), because the
#                       files are read line by line; results still need O(s).
# Example: s=60, f=30, l=60 -> 1,800 line reads versus 108,000 line reads.
# The dictionary method is s times faster for a little extra memory.

def reread_for_student(folder_name, reg_no):
    """Alternative - re-read ALL files for ONE student.
    Returns: present_count, total_count, lines_read"""
    present_count = 0
    total_count = 0
    lines_read = 0

    for file_path in sorted(Path(folder_name).glob("attendance_*.txt")):
        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                lines_read += 1
                line = line.strip()
                if line == "":
                    continue
                student, status, error = check_line(line)
                if error is None and student == reg_no:
                    total_count += 1
                    if status == "P":
                        present_count += 1

    return present_count, total_count, lines_read


# =====================================================================
# MAIN - runs every task in order
# =====================================================================
def main():
    folder_name = "biometric_oct"
    report_name = "attendance_report.txt"
    log_name = "damaged_lines.log"

    # ---------------- TASK 2.1 ----------------
    print("===== TASK 2.1 : INPUT FILE FORMAT (attendance_2026-10-02.txt) =====")
    create_sample_files(folder_name)
    show_file(Path(folder_name) / "attendance_2026-10-02.txt")
    print()

    # ---------------- TASK 2.2 + 2.3 ----------------
    print("===== TASK 2.2 + 2.3 : PROCESS THE MONTH, WRITE THE OUTPUT FILES =====")
    try:
        present, total, damaged, lines_read = process_month(folder_name)
    except FileNotFoundError:
        print("Error: folder", folder_name, "was not found.")
        return

    write_reports(present, total, damaged, report_name, log_name)

    print("----- " + report_name + " -----")
    show_file(report_name)
    print()
    print("----- " + log_name + " -----")
    show_file(log_name)
    print()

    # ---------------- TASK 2.4 ----------------
    print("===== TASK 2.4 : TRACE =====")
    trace_one_file(Path(folder_name) / "attendance_2026-10-02.txt")
    print()

    # ---------------- ALTERNATIVE ----------------
    print("===== ALTERNATIVE CONCEPT : RE-READ ALL FILES FOR EACH STUDENT =====")
    same = True
    reread_lines = 0
    for reg_no in total:
        p, t, n = reread_for_student(folder_name, reg_no)
        reread_lines = reread_lines + n
        if p != present[reg_no] or t != total[reg_no]:
            same = False

    print("Lines read, one pass with dictionary :", lines_read)
    print("Lines read, re-reading per student   :", reread_lines)
    print("Same attendance by both methods?     :", same)


main()